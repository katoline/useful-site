Local security build, not an upstream npm release.

libwebp 1.6.0: 4fa21912338357f89e4fd51cf2368325b59e9bd9
jSquash glue: 641dcc6b853382d57450466bd61b76f9d022242e
Emscripten: 3.1.45

Replaces both encoder and decoder, including fixes for CVE-2023-4863 and CVE-2023-1999. Uses the baseline encoder on all devices. Lossless/lossy APIs are preserved; SIMD acceleration is temporarily absent.
