ローカルセキュリティビルド（上流npmリリースではありません）。

Gifsicle 1.98: 8ff3057b736141b406be621830b851fdf4285689
Emscripten 3.1.45: c8dcb45665fec5e743336703f1d22a191810f2a8

1.92のWASMとglueを両方交換し、1.98のメモリ安全性修正を取り込みます。
対応ソースはsource/gifsicle-1.98.tar.gz、ライセンスはLICENSE.gifsicle。
再ビルドはkatoline/useful-siteの.github/workflows/rebuild-gif-codec.ymlと
scripts/package-gif-security.pyを参照してください。
